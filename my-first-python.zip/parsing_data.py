import requests

url = 'https://api.github.com/user'

userResponse = requests.get(url,headers={'Authorization' : 'Bearer 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'})

myUserResponse = userResponse.json()
print(userResponse.json())

for anyKey in myUserResponse:
    print(anyKey)
    print(myUserResponse[anyKey])
    print('\n')