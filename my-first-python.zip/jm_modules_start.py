
# Import tutorial in python

import math

result = math.sqrt(16)
print(result)

print("The value of pi is", math.pi)